import { Component, OnInit } from '@angular/core';
import { SaveService } from '../save.service';
import { news } from '../models/dashboard.model';
import { Articles } from '../models/dashboard.model';
import { forkJoin } from 'rxjs';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  public responseData1: Articles[];

  public responseData2: Articles[];


//debugger;

  public errormsg;
  constructor(private saveservice: SaveService) { }

  ngOnInit() {
   //debugger;
    forkJoin(this.saveservice.getBusinessNewsdetail(), this.saveservice.getTechNewsdetail()).subscribe(data => {
        this.responseData1 = data[0].articles;
        this.responseData2 = data[1].articles;
    });
    // this.saveservice.getdashdetail()
    // .subscribe(responseList => {

    //   //this.responseData1 = responseList[0];//{status: "ok", totalResults: 70, articles: Array(20)}
    //   this.responseData1 = responseList[0].articles;
    //   this.responseData2 = responseList[1].articles;

    //  console.log(this.responseData1);
    //  console.log(this.responseData2);

    // },
    //   error =>this.errormsg=error
    //   );

    /* 
     this.saveservice.getdashdetail()
     .subscribe(responseList => {
 
       this.responseData1 = responseList[0].articles;
 
       this.responseData2 = responseList[1].articles;
 
      console.log(this.responseData1);
      console.log(this.responseData2);
 
     },
       error =>this.errormsg=error
       );
      */
  }

}
