import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { NavbarComponent } from './navbar/navbar.component';
import {MaterialModule} from './material.module';
import { RegisterComponent } from './register/register.component';
import { ReactiveFormsModule } from '@angular/forms';
import { AboutComponent } from './about/about.component';
import {FlexLayoutModule} from '@angular/flex-layout';
import { SaveService } from './save.service';
import { FlexLoginComponent } from './flex-login/flex-login.component';
import { HttpClientModule } from '@angular/common/http';
import { UserListComponent } from './user-list/user-list.component';
import { MenuListComponent } from './menu-list/menu-list.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LogoutComponent } from './logout/logout.component';
import { RegistrationStepperComponent } from './registration-stepper/registration-stepper.component';
import { ProfileComponent } from './profile/profile.component';
import { ComposeMessageComponent } from './compose-message/compose-message.component';
import { InboxMessageComponent } from './inbox-message/inbox-message.component';
import { SentMessageComponent } from './sent-message/sent-message.component';
import { MatConfirmDialogComponent } from './mat-confirm-dialog/mat-confirm-dialog.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    NavbarComponent,
    RegisterComponent,
    AboutComponent,
    FlexLoginComponent,
    UserListComponent,
    MenuListComponent,
    DashboardComponent,
    LogoutComponent,
    RegistrationStepperComponent,
    ProfileComponent,
    ComposeMessageComponent,
    InboxMessageComponent,
    SentMessageComponent,
    MatConfirmDialogComponent,
  
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    HttpClientModule,
 
  ],
  providers: [SaveService],
  bootstrap: [AppComponent],
  entryComponents: [MatConfirmDialogComponent]
})
export class AppModule { }
