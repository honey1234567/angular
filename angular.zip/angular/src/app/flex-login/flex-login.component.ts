import { Component, OnInit } from '@angular/core';
import { LoginModel } from '../models/login.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SaveService } from '../save.service';


@Component({
  selector: 'app-flex-login',
  templateUrl: './flex-login.component.html',
  styleUrls: ['./flex-login.component.scss'],
  providers: [SaveService]
})
export class FlexLoginComponent implements OnInit {
  public person=[];
  user: LoginModel = new LoginModel();
  loginForm: FormGroup;
  hide = true;
  constructor(private formBuilder: FormBuilder,
    private _check: SaveService
    ) { }

    ngOnInit() {
      this.loginForm = this.formBuilder.group({
        'userEmail': [this.user.userEmail, [
          Validators.required,
          Validators.email
        ]],
        'userPassword': [this.user.userPassword, [
          Validators.required,
          Validators.minLength(6),
          Validators.maxLength(30)
        ]]
      });
    }
  
    onLoginSubmit() :any{
      this.person=this._check.getusers();
      console.log(this.person);
      console.log(this.person[0]);
      console.log(this.person[0]["email"]);
      if(this.user.userEmail==this.person[0]["email"])
      {
       alert(this.user.userEmail + ' ' + this.user.userPassword);
      }
      }
}

