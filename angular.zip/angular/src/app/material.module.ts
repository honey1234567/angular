import {NgModule} from '@angular/core';
import{
	MatToolbarModule,
	 MatButtonModule,
    MatInputModule,
    MatIconModule,
    MatCardModule,
    MatStepperModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatListModule,

   
}from '@angular/material';
@NgModule({
  imports: [
        MatToolbarModule,
        MatButtonModule,
        MatInputModule,
        MatIconModule,
        MatCardModule,
        MatStepperModule,
        MatTableModule,
        MatPaginatorModule,
        MatSortModule,
        MatListModule,
      
   
       
  ],
 exports:[

       MatToolbarModule,
        MatButtonModule,
        MatInputModule,
        MatIconModule,
        MatCardModule,
        MatStepperModule,
        MatSortModule,
        MatPaginatorModule,
        MatTableModule,
        MatListModule,
    
       
      
 ]
})
export class MaterialModule { }
