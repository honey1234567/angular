import {NgModule} from '@angular/core';
import{
	MatToolbarModule,
	 MatButtonModule,
    MatInputModule,
    MatIconModule,
    MatCardModule,
    MatStepperModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatListModule,
    MatTabsModule,
    MatDialogModule,
    MatSidenavModule,
    MatSelectModule
  
   
}from '@angular/material';
@NgModule({
  imports: [
        MatToolbarModule,
        MatButtonModule,
        MatInputModule,
        MatIconModule,
        MatCardModule,
        MatStepperModule,
        MatTableModule,
        MatPaginatorModule,
        MatSortModule,
        MatListModule,
        MatTabsModule,
        MatDialogModule,
        MatSidenavModule,
        MatSelectModule
      
   
       
  ],
 exports:[

       MatToolbarModule,
        MatButtonModule,
        MatInputModule,
        MatIconModule,
        MatCardModule,
        MatStepperModule,
        MatSortModule,
        MatPaginatorModule,
        MatTableModule,
        MatListModule,
        MatTabsModule,
        MatDialogModule,
        MatSidenavModule,
        MatSelectModule
    
       
      
 ]
})
export class MaterialModule { }
