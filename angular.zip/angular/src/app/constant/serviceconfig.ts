export var serviceconfig = {
    SERVER_URL: "http://localhost:8080/TechLoopService/",
    MODAL_URL: "Menu/",
    NEWS_API_KEY: "e4bd3e2ab4f54826b967dc6a3b8e0870",

    NEWS_BUSINESS: "https://newsapi.org/v2/top-headlines?country=in&category=business&apiKey=",
    NEWS_TECH: "https://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=",
    GET_MENU_LIST: "get-std-menu-list",
    SEND_MESSAGE: "send-message",
    MSG_SERVICE: "Message/",
    INBOX_MESSAGE: "inbox-message",
    SENT_MESSAGE: "sent-message"
}