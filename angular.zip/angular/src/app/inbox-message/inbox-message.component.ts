
import {Component, OnInit,ViewChild} from '@angular/core';
import { InboxMessageModel } from '../models/inbox.model';

import { SaveService } from '../save.service';
import { MessageModel } from '../models/message.model';
import { MatTableDataSource ,MatPaginator} from '@angular/material';


/**
 * @title Basic use of `<table mat-table>`
 */
@Component({
  selector: 'app-inbox-message',
  styleUrls: ['./inbox-message.component.scss'],
  templateUrl: './inbox-message.component.html',
  providers: [SaveService]
})
export class InboxMessageComponent implements OnInit{
  displayedColumns: string[] = ['Subject', 'SentBy', 'Message', 'SentTime'];
  //dataSource = ELEMENT_DATA;

  public errormsg;
 //public auth_data = [];
 public auth_data: MessageModel[];

 dataSource: any;

  public username: InboxMessageModel = new InboxMessageModel();;

  constructor(private saveservice: SaveService) { }
  @ViewChild(MatPaginator,{static: true}) paginator: MatPaginator;//hold of a reference of a matpaginator
  ngOnInit() {
     //debugger;
    this.username.userEmail = JSON.parse(sessionStorage.getItem("UserDetails")).userEmail;

    this.saveservice.get_messages(this.username)
      .subscribe(data => {
        this.auth_data = data;
        var j;
        for(j in this.auth_data ) { 
        
          this.auth_data [j]["msgModifiedDateTime"]=new Date(this.auth_data[j]["msgModifiedDateTime"]);
       }
        //this.auth_data[0]["msgModifiedDateTime"]= new Date(this.auth_data[0]["msgModifiedDateTime"]);
        this.dataSource =new MatTableDataSource(this.auth_data);
        this.dataSource.paginator =this.paginator;
        console.log(this.auth_data);//show all messages
       
      }, error => (this.errormsg = error)
      );
    console.log(this.auth_data);  //showing empty data because getting response from service will take some time and observable will execute them parallely
    //so make sure whatever result you are getting from service should be printed inside block.

  }
  applyFilter(searchkey: string)
  {
    this.dataSource.filter=searchkey.trim().toLowerCase();
  }
}


