

import { Component, OnInit } from '@angular/core';

import { RegisterModel } from '../models/register.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SaveService } from '../save.service';
import { debugOutputAstAsTypeScript } from '@angular/compiler';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
  //providers: [SaveService]
})
export class RegisterComponent implements OnInit {
  user: RegisterModel = new RegisterModel();
  isDone: boolean = false;
  registerForm: FormGroup;
  hide = true;
  public errormsg;
  constructor(private formBuilder: FormBuilder,
    private saveservice: SaveService
  ) { }
  // constructor(private saveservice: SaveService) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      'userName': [this.user.userName, [
        Validators.required
      ]],
      'userEmail': [this.user.userEmail, [
        Validators.required,
        Validators.email
      ]],
      'userPassword': [this.user.userPassword, [
        Validators.required,
        Validators.minLength(6),
        Validators.maxLength(30)
      ]],
      'userPhone': [this.user.userPhone, [
        Validators.required
      ]],
      'userGender': [this.user.userGender, [
        Validators.required
      ]]
    });
  }
  onRegisterSubmit(): any {
  // debugger;
    //alert(this.user.name + ' ' + this.user.email + ' ' + this.user.password);

    //this.saveservice.add(this.user);


    //alert("Registration done sucessfully");
    this.saveservice.add_bravura_server(this.user)
     .subscribe(result => {
        this.isDone = result;
        console.log(this.user);
        if (this.isDone == true) {
          alert("sucessfully registered");
        }

        else {
          alert("can't be registered");
        }
       // this.saveservice.add(this.user);

        console.log(result);
      }, error => {
        this.errormsg = error;
        console.log(this.errormsg);
      }
      );
      

/*
      if (this.isDone == true) {
        alert("sucessfully added to bravura server");
      }

      else {
        alert("sorry!!!cannt be added to bravura server");
      }
  */
    }

}


/*
import { Component, OnInit } from '@angular/core';

import { RegisterModel } from '../models/register.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SaveService } from '../save.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
  providers: [SaveService]
})
export class RegisterComponent implements OnInit {
  user: RegisterModel = new RegisterModel();

  registerForm: FormGroup;
   hide = true;

  constructor(private formBuilder: FormBuilder,
    private saveservice: SaveService
  ) {}
 // constructor(private saveservice: SaveService) { }

  ngOnInit() {
  this.registerForm = this.formBuilder.group({
      'name': [this.user.name, [
        Validators.required
      ]],
      'email': [this.user.email, [
        Validators.required,
        Validators.email
      ]],
      'password': [this.user.password, [
        Validators.required,
        Validators.minLength(6),
        Validators.maxLength(30)
      ]]
    });
  }
    onRegisterSubmit(): void {
    //alert(this.user.name + ' ' + this.user.email + ' ' + this.user.password);

    this.saveservice.add(this.user);

    alert("Registration done sucessfully");
  }

}
*/