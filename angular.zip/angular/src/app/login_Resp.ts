export interface Ilogin_Resp
{
    userSeqNo: number,
    userName: string,
    userEmail: string,
    userPassword: string,
    userPhone: string,
    userGender: string,
    userIsDelete: string,
    userToken: string,
    userTokenId:string,
    userCreatedDateTime: string,
    userModifiedDateTime: string
}