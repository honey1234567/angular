//import {Observable} from 'rxjs/Observable';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { LoginModel } from '../models/login.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SaveService } from '../save.service';
import { Ilogin_Resp } from '../login_Resp';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Imenu_Resp } from '../menu';
import { NavbarComponent } from '../navbar/navbar.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  //providers: [SaveService]
})
export class LoginComponent implements OnInit {
  public person;
  public auth: any; 
  public auth_data1 = [];
  public person1: Ilogin_Resp;
  user: LoginModel = new LoginModel();
  data1: Ilogin_Resp;
  loginForm: FormGroup;
  @Output() public childEvent = new EventEmitter();
  hide = true;
  public errormsg;
  public isloggedin = false;
  public default_page = true;
  subscription: Subscription;
  menuModal: Imenu_Resp[];

  constructor(private formBuilder: FormBuilder,
    private saveService: SaveService, private router: Router, private navbar: NavbarComponent
  ) { this.isloggedin = this.saveService.getLoginStatus(); }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      'userEmail': [this.user.userEmail, [
        Validators.required,
        Validators.email
      ]],
      'userPassword': [this.user.userPassword, [
        Validators.required,
        Validators.minLength(6),
        Validators.maxLength(30)
      ]]
    });
  }

  onLoginSubmit(): any {
    debugger;
    this.person = this.saveService.getusers();
    console.log(this.person);
    console.log(this.person[0]);
    console.log(this.person[0]["email"]);
    if (this.user.userEmail == this.person[0]["email"]) {
      //alert(this.user.userEmail + ' ' + this.user.userPassword);
    }
    this.saveService.get_login_data(this.user)
      .subscribe(data => {
        // debugger;
        this.person1 = data;
        console.log(this.person1);
        if (this.person1 != null) {

          this.setSessionValue(this.person1);
          this.navbar.ngOnInit();
          // this._check.get_auth_data()
          // .subscribe(data =>{
          //   this.auth_data1=data;
          //   console.log(this.auth_data1);
          //   this.isloggedin=true;
          //   this._check.updateNavAfterAuth();
          //   this._check.updateLoginStatus(true);
          //   console.log(this._check.getLinks());
          //   this.childEvent.emit(this._check.getLinks());
          // },error=>(this.errormsg=error)
          //   );
        }
      }, error => (this.errormsg = error)
      );
  }

  setSessionValue(userDetail: Ilogin_Resp) {

    sessionStorage.setItem("UserDetails", JSON.stringify(userDetail));//converting json to string because in session we can store only string value
    sessionStorage.setItem("isAuth", "Y");
    //this.saveService.getMenuList("Y");
    //let abc =new NavbarComponent(this.saveService , this.router);
    //abc.ngOnInit();
    // this.subscription = this.saveService.notifyObservable$.subscribe(data => {
    //   this.menuModal = data;
    // });
  }
}
