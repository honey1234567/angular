import { Component, OnInit } from '@angular/core';
import { SaveService } from '../save.service';

@Component({
  selector: 'app-menu-list',
  templateUrl: './menu-list.component.html',
  styleUrls: ['./menu-list.component.scss'],
  providers: [SaveService]
})
export class MenuListComponent implements OnInit {
public auth:any;
public errormsg;
public auth_data=[];
public auth_data1=[];
  constructor(  private _check: SaveService) { }

  ngOnInit() {
  debugger

    this._check.get_auth_data()
    .subscribe(data =>{
      this.auth_data1=data;
      console.log(this.auth_data1);
    },error=>(this.errormsg=error)
      );
      
    this._check.get_nauth_data()
    .subscribe(data =>{
      this.auth_data=data;
      console.log(this.auth_data);
    },error=>(this.errormsg=error)
      );
  }
    
    

}
