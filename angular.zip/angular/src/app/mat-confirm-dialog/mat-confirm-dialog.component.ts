import { Component, OnInit,Inject } from '@angular/core';
import{ MAT_DIALOG_DATA,MatDialogRef} from '@angular/material';

@Component({
  selector: 'app-mat-confirm-dialog',
  templateUrl: './mat-confirm-dialog.component.html',
  styleUrls: ['./mat-confirm-dialog.component.scss']
})
export class MatConfirmDialogComponent implements OnInit {

  formData : Data;
  constructor(@Inject(MAT_DIALOG_DATA) public data, public dialogref: MatDialogRef<MatConfirmDialogComponent>) { 
    this.formData = data ;
    console.log(this.formData);
  }

  ngOnInit() {
  }
closeDialog(){
this.dialogref.close();
}

}

export class Data{
  messaeObject : [];
  messaeBody : string;
  messaeHeader : string;
}
