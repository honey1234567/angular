export interface Imenu_Resp {
    menuSeqNo: number,
    menuSortDescription: string,
    menuDescription: string,
    menuCode: string,
    menuName: string,
    menuURl: string,
    menuAuth: string,
    menuIsDelete: string,
    menuIcon: string,
    menuCreatedDateTime: number,
    menuModifiedDateTime: number
   
}