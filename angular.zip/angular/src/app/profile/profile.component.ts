import { Component, OnInit } from '@angular/core';
import { Ilogin_Resp } from '../login_Resp';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  public users: any;
  public userobj;
  constructor() { }

  ngOnInit() {

    this.users = sessionStorage.getItem("UserDetails");//Here result is a string
    //convert to json object to get it by key
    this.userobj = JSON.parse(this.users);// convert to json object
    console.log(this.users);//result in json string

    console.log(this.userobj.userName);

  }

}
