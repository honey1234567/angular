import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { AboutComponent } from './about/about.component';
import { RegisterComponent } from './register/register.component';
import { UserListComponent } from './user-list/user-list.component';
import { MenuListComponent } from './menu-list/menu-list.component';
import { FlexLoginComponent } from './flex-login/flex-login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ProfileComponent } from './profile/profile.component';
import { RegistrationStepperComponent } from './registration-stepper/registration-stepper.component';
import { ComposeMessageComponent } from './compose-message/compose-message.component';
import { InboxMessageComponent } from './inbox-message/inbox-message.component';
import { SentMessageComponent } from './sent-message/sent-message.component';

const routes: Routes = [{
	path: 'registration-page',
	component: RegisterComponent
}, {
	path: 'login-page',
	component: LoginComponent

}, {
	path: 'about',
	component: AboutComponent,
	runGuardsAndResolvers: 'always'
}, {
	path: 'flex-login',
	component: FlexLoginComponent
}, {
	path: 'user-list',
	component: UserListComponent
}, {
	path: 'menu-list',
	component: MenuListComponent
},{
	path: 'dashboard-page',
	component:  DashboardComponent
},{
	path: 'logout-page',
	component:  LogoutComponent
},{
	path: 'registration-stepper',
	component: RegistrationStepperComponent

},{
	path: 'profile-page',
	component: ProfileComponent
},{
	path: 'compose-message-page',
	component: ComposeMessageComponent
},{
	path: 'inbox-message-page',
	component: InboxMessageComponent
},{
	path: 'sent-message-page',
	component: SentMessageComponent
}
];

@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule]
})
export class AppRoutingModule { }
