import { Component, OnInit } from '@angular/core';
import { SaveService } from '../save.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss'],
  providers: [SaveService]
})
export class UserListComponent implements OnInit {
  public users=[];
  public errormsg;
  constructor(private _userservice:SaveService) { }

  ngOnInit() {
    this._userservice.getUsers()
    .subscribe(data => this.users=data,
      error =>this.errormsg=error
      );
  
    }

}
