import { Component, OnInit, Input } from '@angular/core';
import { SaveService } from '../save.service';
import { Imenu_Resp } from '../menu';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
 public errormsg
  private subscription: Subscription;
  links: Array<{ text: string, path: string }>;
  isLoggedIn = false;
  public message = [];
  default = true;
  menuModal: Imenu_Resp[];



  constructor(private navbarService: SaveService, private router: Router) { }

  get(l: []) {
    console.log("in get method");
    this.message = l;
    this.default = false;
  }
 
  ngOnInit() {
    
   // debugger;
   /* debugger;
    if (sessionStorage.getItem("isAuth") === "Y") {
      this.router.navigateByUrl("about");
      this.navbarService.getMenuList("Y");
    } else{
      this.router.navigateByUrl("login-page");
      this.navbarService.getMenuList("N");
    }
    this.subscription = this.navbarService.notifyObservable$.subscribe(data => {
      this.menuModal = data;
    })

  }
*/

if (sessionStorage.getItem("isAuth") === "Y") {

  //this.router.navigateByUrl("about");
this.navbarService.getMenuList1("Y")
.subscribe(data =>{
 // alert(data);
  this.menuModal=data;
  //alert(this.menuModal);
  console.log(this.menuModal);
},error=>(this.errormsg=error)
  );


  //alert("authenticated");
  //this.router.navigateByUrl("about",{skipLocationChange: true});
  this.router.navigateByUrl("dashboard-page");
}
else{
  this.router.navigateByUrl("login-page");

  this.navbarService.getMenuList1("N")
  .subscribe(data =>{
   // alert(data);
    this.menuModal=data;
    console.log(this.menuModal);
  },error=>(this.errormsg=error)
    );
}
}
}
