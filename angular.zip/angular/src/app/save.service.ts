//import { Observable, of } from 'rxjs';//Just import without installing package
//install only for mat des and flex
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
//import { Server } from 'net';
import { Observable, observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpHeaders } from '@angular/common/http';
import { Ilogin_Resp } from './login_Resp';
import { news } from './models/dashboard.model';
import { Imenu_Resp } from './menu';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';

import { LoginModel } from './models/login.model';
import { RegisterModel } from './models/register.model';
import { ComposeMessageModel } from './models/composemessage.model';
import { InboxMessageModel } from './models/inbox.model';
import { SentMessageModel } from './models/sent.model';
import { MessageModel } from './models/message.model';
import { Subject } from 'rxjs';

import { forkJoin } from 'rxjs';

import { serviceconfig as sc } from '../app/constant/serviceconfig';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token'
  })
};
@Injectable({
  providedIn: 'root'
}
)
export class SaveService {
  //data: RegisterModel=[];
  //ERROR in src/app/save.service.ts(13,3): error TS2739: Type 'undefined[]' is missing the following properties from type 'RegisterModel': name, email, password
  //c/app/save.service.ts(20,15): error TS2339: Property 'push' does not exist on type 'RegisterModel'.
  public data = []
  private _url: string = "http://localhost:8080/TechLoopService/User/user-registration";
  private resp_url: string = "http://localhost:8080/TechLoopService/User/user-login";
  private user_url: string = "http://localhost:8080/TechLoopService/User/get-user-details";
  public auth_url: string = "http://localhost:8080/TechLoopService/Menu/get-std-menu-list?isAuth=Y";
  public nauth_url: string = "http://localhost:8080/TechLoopService/Menu/get-std-menu-list?isAuth=N";
  public links = new Array<{ text: string, path: string }>();
  public isLoggedIn: boolean;
  //private isLoggedIn = new Subject<boolean>();
  constructor(private http: HttpClient, private route: ActivatedRoute, private router: Router) {

    this.links.push({ text: 'About', path: '/about' });
    this.links.push({ text: 'Register', path: '/register' });
    this.links.push({ text: 'Login', path: 'this.route' });
    this.links.push({ text: 'FlexLogin', path: '/flex-login' });


    console.log(this.data);
    this.isLoggedIn = false;
  }
  /////////////////////////////////

  private notifyMenu = new Subject<Imenu_Resp[]>();
  notifyObservable$ = this.notifyMenu.asObservable();

  getMenuList(param: string) {//this method will also work same as below on calling this from app.ts/nav.ts

    this.http.get<Imenu_Resp[]>(sc.SERVER_URL + sc.MODAL_URL + sc.GET_MENU_LIST + "?isAuth=" + param, httpOptions).subscribe(res => {
      this.notifyMenu.next(res);
    })


  }
  getMenuList1(param: string): Observable<Imenu_Resp[]> {

    return this.http.get<Imenu_Resp[]>(sc.SERVER_URL + sc.MODAL_URL + sc.GET_MENU_LIST + "?isAuth=" + param, httpOptions);

    // return this.http.get<Imenu_Resp[]>(sc.SERVER_URL + sc.MODAL_URL + sc.GET_MENU_LIST + "?isAuth=" + param, httpOptions)
    // .pipe(
    //   catchError(this.handleError)
    // );

  }






  ///////////////////////////
  getLoginStatus() {
    return this.isLoggedIn;
  }
  add(dat: RegisterModel): void {
    this.data.push(dat);
    console.log(this.data);


  }
  updateLoginStatus(status: boolean) {
    this.isLoggedIn = status;
  }
  getusers(): any {
    return ([{ email: "shreyags1998@gmail.com", password: "sherpauts" }]);
  }
  getUsers(): Observable<Ilogin_Resp[]> {
    return this.http.get<Ilogin_Resp[]>(this.user_url, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }
  get_auth_data(): Observable<Imenu_Resp[]> {
    return this.http.get<Imenu_Resp[]>(this.auth_url, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }
  get_messages(data: InboxMessageModel): Observable<MessageModel[]> {
    //debugger;
    return this.http.post<MessageModel[]>(sc.SERVER_URL + sc.MSG_SERVICE + sc.INBOX_MESSAGE,data,httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }
 
  get_sent_messages(data: SentMessageModel): Observable<MessageModel[]> {
    //debugger;
    return this.http.post<MessageModel[]>(sc.SERVER_URL + sc.MSG_SERVICE + sc.SENT_MESSAGE,data,httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }
  get_nauth_data(): Observable<Imenu_Resp[]> {
    return this.http.get<Imenu_Resp[]>(this.nauth_url, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }
  get_login_data(dat1: LoginModel): Observable<Ilogin_Resp> {
    return this.http.post<Ilogin_Resp>(this.resp_url, dat1, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }
  getLinks(): any {
    console.log(this.links);
    return this.links;
  }
  getBusinessNewsdetail(): Observable<news> {
    //debugger;
    return this.http.get<news>(sc.NEWS_BUSINESS + sc.NEWS_API_KEY);

  }

  getTechNewsdetail(): Observable<news> {
    //debugger;
    return this.http.get<news>(sc.NEWS_TECH + sc.NEWS_API_KEY);
  }
  /*
  public getdashdetail(): Observable<any> {

    let response1 = this.http.get<any>(sc.NEWS_BUSINESS + sc.NEWS_API_KEY);

    let response2 = this.http.get<any>(sc.NEWS_TECH + sc.NEWS_API_KEY);



    // Observable.forkJoin (RxJS 5) changes to just forkJoin() in RxJS 6

    return forkJoin([response1, response2]);

  }
*/
  updateNavAfterAuth(): void {

    this.links.length = 0;
    this.links.push({ text: 'About1', path: '/about' });
  }
  add_bravura_server(dat: RegisterModel): Observable<boolean> {
    return this.http.post<boolean>(this._url, dat, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }
  send_message(dat: ComposeMessageModel): Observable<boolean> {
    return this.http.post<boolean>(sc.SERVER_URL + sc.MSG_SERVICE + sc.SEND_MESSAGE,dat,httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }
  handleError(error: HttpErrorResponse) {
    return Observable.throw(error.message || "server error");//if error.msg is null we just throw the string server error
  }


}

/*
//import { Observable, of } from 'rxjs';//Just import without installing package
//install only for mat des and flex
import { Injectable } from '@angular/core';
//import { Server } from 'net';

import { RegisterModel } from './models/register.model';


@Injectable(
  //providedIn: 'root'
)
export class SaveService {
  //data: RegisterModel=[];
  //ERROR in src/app/save.service.ts(13,3): error TS2739: Type 'undefined[]' is missing the following properties from type 'RegisterModel': name, email, password
//c/app/save.service.ts(20,15): error TS2339: Property 'push' does not exist on type 'RegisterModel'.
  public data=[]
  constructor() {

    console.log(this.data);
   }
  add(dat: RegisterModel): void
  {
    this.data.push(dat);
    console.log(this.data);


  }
  getusers():any{
    return ([{email:"shreyags1998@gmail.com",password:"sherpauts"}]);
  }


 // constructor() { }
}

*/