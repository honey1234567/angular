import { Component, OnInit } from '@angular/core';
import { SaveService } from '../save.service';
import { Router } from '@angular/router';
import { NavbarComponent } from '../navbar/navbar.component';
@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.scss'],
  providers: [SaveService]
})
export class LogoutComponent implements OnInit {

  constructor(private router: Router,private navbar:NavbarComponent) { }

  ngOnInit() {
    sessionStorage.clear();
    this.navbar.ngOnInit(); 
    //this.router.navigate(["login-page"]);

  }

}
