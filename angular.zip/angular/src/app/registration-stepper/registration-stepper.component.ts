import { Component, OnInit } from '@angular/core';

import { RegisterModel } from '../models/register.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SaveService } from '../save.service';
@Component({
  selector: 'app-registration-stepper',
  templateUrl: './registration-stepper.component.html',
  styleUrls: ['./registration-stepper.component.scss'],
 // providers: [SaveService]
})
export class RegistrationStepperComponent implements OnInit {
  user: RegisterModel = new RegisterModel();
  hide = true;
  horizontal=true;
  NameEmail: FormGroup;
  PhoneGender: FormGroup;
  Password: FormGroup;
  isDone: boolean = false;
  public errormsg;
  constructor(private formBuilder: FormBuilder, private saveservice: SaveService) { }

  ngOnInit() {
    this. NameEmail = this.formBuilder.group({
      'userName': [this.user.userName, [
        Validators.required
      ]],
      'userEmail': [this.user.userEmail, [
        Validators.required,
        Validators.email
      ]]
    });
    this.PhoneGender = this.formBuilder.group({
      'userPhone': [this.user.userPhone, [
        Validators.required
      ]],
      'userGender': [this.user.userGender, [
        Validators.required
       
      ]]
    });
    this.Password = this.formBuilder.group({
      'userPassword': [this.user.userPassword, [
        Validators.required,
        Validators.minLength(6),
        Validators.maxLength(30)
      ]]
    });
  }
  onRegisterSubmit(): any {
    // debugger;
      //alert(this.user.name + ' ' + this.user.email + ' ' + this.user.password);
  
      //this.saveservice.add(this.user);
  
  
      //alert("Registration done sucessfully");
      this.saveservice.add_bravura_server(this.user)
       .subscribe(result => {
          this.isDone = result;
          if (this.isDone == true) {
            alert("sucessfully registered");
          }
  
          else {
            alert("can not be registered");
          }
         // this.saveservice.add(this.user);
  
          console.log(result);
        }, error => {
          this.errormsg = error;
          console.log(this.errormsg);
        }
        );
    }
    changelayout(): any{
     this.horizontal=!this.horizontal;
    }

}
