import { Component, OnInit,ViewChild } from '@angular/core';
import { SentMessageModel } from '../models/sent.model';
import { SaveService } from '../save.service';
import { MessageModel } from '../models/message.model';
import { MatTableDataSource ,MatPaginator} from '@angular/material';
@Component({
  selector: 'app-sent-message',
  templateUrl: './sent-message.component.html',
  styleUrls: ['./sent-message.component.scss']
})
export class SentMessageComponent implements OnInit {
  displayedColumns: string[] = ['Subject', 'SentTo', 'Message', 'SentTime'];
  public errormsg;
  dataSource:any;
  public sent_data:  MessageModel[];
  public username: SentMessageModel = new SentMessageModel();
  constructor(private saveservice: SaveService) { }
  @ViewChild(MatPaginator,{static: true}) paginator: MatPaginator;
  ngOnInit() {
    this.username.userEmail = JSON.parse(sessionStorage.getItem("UserDetails")).userEmail;

    this.saveservice.get_sent_messages(this.username)
      .subscribe(data => {
        this.sent_data = data;
        var j;
        for(j in this.sent_data ) { 
          this.sent_data [j]["msgModifiedDateTime"]=new Date(this.sent_data[j]["msgModifiedDateTime"]);
       }
        //this.auth_data[0]["msgModifiedDateTime"]= new Date(this.auth_data[0]["msgModifiedDateTime"]);
       
        this.dataSource =new MatTableDataSource(this.sent_data);
        this.dataSource.paginator =this.paginator;
        console.log(this.sent_data);//show all messages
      }, error => (this.errormsg = error)
      );
  }
  applyFilter(searchkey: string)
  {
    this.dataSource.filter=searchkey.trim().toLowerCase();
  }
}
