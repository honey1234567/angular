import { Component, OnInit } from '@angular/core';
import { ComposeMessageModel } from '../models/composemessage.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SaveService } from '../save.service';
import { DialogService } from '../dialog.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-compose-message',
  templateUrl: './compose-message.component.html',
  styleUrls: ['./compose-message.component.scss'],
  providers: [SaveService]
})
export class ComposeMessageComponent implements OnInit {
  user: ComposeMessageModel = new ComposeMessageModel();
  isDone: boolean = false;
  SendMessageForm: FormGroup;
  public sender:any;

  public errormsg;
  constructor(private formBuilder: FormBuilder,
    private saveservice: SaveService,private router: Router,private dialogservice: DialogService
  ) { }
  // constructor(private saveservice: SaveService) { }

  ngOnInit() {
    //debugger;
    this.sender = JSON.parse(sessionStorage.getItem("UserDetails")).userEmail;// convert to json object
    //this.user.msgFromEmail=this.sender;
    
    this.SendMessageForm = this.formBuilder.group({
      'msgToEmail': [this.user.msgToEmail, [
        Validators.required
      ]],
      'msgFromEmail': [this.user.msgFromEmail=this.sender, [
        Validators.required
      ]
        ],

      'msgSubject': [this.user.msgSubject, [
        Validators.required

      ]],
      'msgMessage': [this.user.msgMessage, [
        Validators.required
      ]]
    });
   
   
  }
  onSendMessageSubmit(): any {
    // debugger;
    //alert(this.user.name + ' ' + this.user.email + ' ' + this.user.password);

    //this.saveservice.add(this.user);


    //alert("Registration done sucessfully");
    this.saveservice.send_message(this.user)
      .subscribe(result => {
        this.isDone = result;
        console.log(this.user);
        console.log(this.isDone);
        if (this.isDone == true) {
          this.dialogservice.openConfirmDialog("Sucessfully Sent",null,null);
          this.user.msgToEmail=" ";
          this.user.msgSubject=" ";
          this.user.msgMessage=" ";
        //  this.router.navigateByUrl("compose-message-page"); or by refreshing the page by visiting again all the data can be lost after sending.

        }

        else {
          this.dialogservice.openConfirmDialog("oops!!!cann't be sent",null,null);
        }
        // this.saveservice.add(this.user);

        console.log(result);
      }, error => {
        this.errormsg = error;
        console.log(this.errormsg);
      }
      );
    
  }

}





