import { Component, OnInit } from '@angular/core';
import { ComposeMessageModel } from '../models/composemessage.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SaveService } from '../save.service';
@Component({
  selector: 'app-compose-message',
  templateUrl: './compose-message.component.html',
  styleUrls: ['./compose-message.component.scss'],
  providers: [SaveService]
})
export class ComposeMessageComponent implements OnInit {
  user: ComposeMessageModel = new ComposeMessageModel();
  isDone: boolean = false;
  SendMessageForm: FormGroup;
  public sender:any;

  public errormsg;
  constructor(private formBuilder: FormBuilder,
    private saveservice: SaveService
  ) { }
  // constructor(private saveservice: SaveService) { }

  ngOnInit() {
    this.sender = JSON.parse(sessionStorage.getItem("UserDetails")).userEmail;// convert to json object
    //this.user.msgFromEmail=this.sender;
    
    this.SendMessageForm = this.formBuilder.group({
      'msgToEmail': [this.user.msgToEmail, [
        Validators.required
      ]],
      'msgFromEmail': [this.user.msgFromEmail=this.sender, [
        Validators.required
      ]
        ],

      'msgSubject': [this.user.msgSubject, [
        Validators.required

      ]],
      'msgMessage': [this.user.msgMessage, [
        Validators.required
      ]]
    });
   
   
  }
  onSendMessageSubmit(): any {
    // debugger;
    //alert(this.user.name + ' ' + this.user.email + ' ' + this.user.password);

    //this.saveservice.add(this.user);


    //alert("Registration done sucessfully");
    this.saveservice.send_message(this.user)
      .subscribe(result => {
        this.isDone = result;
        console.log(this.user);
        console.log(this.isDone);
        if (this.isDone == true) {
          alert("sent");
        }

        else {
          alert("sorry!!!");
        }
        // this.saveservice.add(this.user);

        console.log(result);
      }, error => {
        this.errormsg = error;
        console.log(this.errormsg);
      }
      );
    
  }

}





