export class RegisterModel {
    userName: String;
    userEmail: String;
    userPassword: String;
    userPhone: String;
    userGender:String;
}
/*export class RegisterModel {
    name: String;
    email: String;
    password: String;
}
*/