export class LoginModel {
    userEmail: String;
    userPassword: String;
}