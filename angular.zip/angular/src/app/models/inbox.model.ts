export class InboxMessageModel {
    userEmail: String;
   
}
