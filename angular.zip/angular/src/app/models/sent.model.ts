export class SentMessageModel {
    userEmail: String;
   
}
