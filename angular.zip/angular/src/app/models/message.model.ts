export interface MessageModel{
    msgSeqNo: number,
    msgToEmail: string,
    msgFromEmail: string,
    msgSubject: string,
    msgMessage: string,
    msgIsDelete: string,
    msgCreatedDateTime: number,
    msgModifiedDateTime: Date
}
