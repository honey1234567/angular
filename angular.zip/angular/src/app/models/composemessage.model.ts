export class ComposeMessageModel {
    msgToEmail: String;
    msgFromEmail: String;
    msgSubject: String;
    msgMessage: String;
    
}
