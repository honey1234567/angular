import { Component, OnInit,Input, Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
public name="shreya";
public myid="test";
public haserror="true";
public sucessclass="text-sucess";
public isspeical="true";
public eventname=" ";
public name2="";
public messageclass={
  "text-sucess": !this.haserror,
  "text-danger": this.haserror
}
@Input() public parentData;
@Output() public childevent=new EventEmitter(); 
public titlestyle={
  color:"blue",
  fontStyle:"italic"
}
public siteurl=window.location.href;//can't directly call global in html so use local variable and call it in html
onclick(event)
{
  console.log("Welcome bravula");
  console.log(event);
  this.eventname=event.type;

}  
log(value){
  console.log(value);
}

constructor() { }

  ngOnInit() {
  }
  firevent(){
    this.childevent.emit("hey codevolution");
  }
greetuser(){
  return "welcome " + this.name;
}
}
