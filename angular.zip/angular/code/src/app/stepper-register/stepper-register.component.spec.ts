import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StepperRegisterComponent } from './stepper-register.component';

describe('StepperRegisterComponent', () => {
  let component: StepperRegisterComponent;
  let fixture: ComponentFixture<StepperRegisterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepperRegisterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepperRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
