import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stepper-register',
  templateUrl: './stepper-register.component.html',
  styleUrls: ['./stepper-register.component.css']
})
export class StepperRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
