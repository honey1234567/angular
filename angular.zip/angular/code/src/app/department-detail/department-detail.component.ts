import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router,ParamMap} from '@angular/router';
@Component({
  selector: 'app-department-detail',
  templateUrl: './department-detail.component.html',
  styleUrls: ['./department-detail.component.css']
})
export class DepartmentDetailComponent implements OnInit {
public departmentId;
  constructor(private route: ActivatedRoute,private router: Router) { }//activated route to read the route parameter
  //snapshot of current route

  ngOnInit() {
    /*let id=parseInt(this.route.snapshot.paramMap.get('id'));
    this.departmentId=id;//this is prev approach
  */
 this.route.paramMap.subscribe((params: ParamMap)=>{
   let id=parseInt(params.get('id'));
   this.departmentId=id;
 });
  }
  goPrevious(){
    let previd=this.departmentId-1;
    this.router.navigate(['/departments1',previd]);
  }
  goNext(){
    let nextid=this.departmentId+1;
    this.router.navigate(['/departments1',nextid]);
  }
gotoDepartments()
{
  let selectedId=this.departmentId ? this.departmentId :null;
  //also work in this way:-
  //let selectedId=this.departmentId;
  this.router.navigate(['/department-list',{id :selectedId}]);//id is a optional route parameter
}
showoverview(){
  this.router.navigate(['overview'],{relativeTo: this.route});
}
showcontact(){
  this.router.navigate(['contact'],{relativeTo: this.route});
}
}
