import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Test2Component } from './test2/test2.component';

import { TestComponent } from './test/test.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { DepartmentListComponent } from './department-list/department-list.component';
import { DepartmentDetailComponent } from './department-detail/department-detail.component';
import { DepartmentOverviewComponent } from './department-overview/department-overview.component';
import { DepartmentContactComponent } from './department-contact/department-contact.component';
import { StepperRegisterComponent } from './stepper-register/stepper-register.component';
const routes: Routes = [{
  
  path:'',//default landing page
  redirectTo:'/employee-list', pathMatch: 'full'//if pathmatch is prefix i.e empty path is prefix of url then redirect to this component
  //but here the problem is empty path is a prefix of every url so always employee-list will be displayed
  //so use 'full' means redirect to employee-list if the full path of url is empty.


},{
  
    path:'test2',
    component:Test2Component
  
  
},{
  
  path:'test',
  component:TestComponent


},{
  
  path:'employee-list',
  component:EmployeeListComponent


},{
  
  path:'department-list',
  component:DepartmentListComponent


},{
  
  path:'departments1/:id',//Any name of path u can give here but it should match with //the router.navigate
  component:DepartmentDetailComponent,
  children:[
    {path:'overview',component:DepartmentOverviewComponent},
    {path:'contact',component:DepartmentContactComponent}
  ]                                     //:id is the placeholder for route parameter
//on select url should change to /departmnets/:id in department-detail component from //department-list component


},{
  
  path:'stepper_register',
  component:StepperRegisterComponent


},
{
  
  path:"**",
  component:EmployeeListComponent//default path when no valid url found it should be //defuned at last otherwise everytime this url will be displayed
//because router matches the path from the top

}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
