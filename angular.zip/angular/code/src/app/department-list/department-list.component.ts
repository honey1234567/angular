import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router,ParamMap} from '@angular/router';
@Component({
  selector: 'app-department-list',
  templateUrl: './department-list.component.html',
  styleUrls: ['./department-list.component.css']
})
export class DepartmentListComponent implements OnInit {
departments=[
  {"id":1,"name":"Angular"},
  {"id":2,"name":"Angular2"},
  {"id":3,"name":"Angular3"},
  {"id":4,"name":"Angular4"}
]
  constructor(private router: Router,private route: ActivatedRoute) { }
public selectedId;
  ngOnInit() {
    this.route.paramMap.subscribe((params: ParamMap)=>{
      let id=parseInt(params.get('id'));
      this.selectedId=id;
    });
  }
onSelect(department){
  this.router.navigate(['/departments1',department.id]);//.navigate contain information that angular needs to construct the url
//calling department detail as matches the path .
}
isSelected(department){
  return department.id === this.selectedId;//matches url param id with each department id in many iteration
}
}
