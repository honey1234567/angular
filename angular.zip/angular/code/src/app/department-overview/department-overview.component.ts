import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-department-overview',
  templateUrl: './department-overview.component.html',
  styleUrls: ['./department-overview.component.css']
})
export class DepartmentOverviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
