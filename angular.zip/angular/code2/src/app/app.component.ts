import { Component } from '@angular/core';
import { User} from './user'
import { EnrollmentService } from './enrollment.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  topics = ['Angular', 'java', 'css'];
  userModel=new User('Rob','dwarka','rob@test.com',55678954,'','morning',true);
  visible = true;
  errorMsg = '';
  topicHasError = true;
  submitted = false;
  constructor(private _enrollmentService: EnrollmentService) {}
  validateTopic(value) {
    if (value === 'default') {
      this.topicHasError = true;
    } else {
      this.topicHasError = false;
    }
  }
  toggle() {
    this.visible = !this.visible;
  }

  onSubmit() {
    this.submitted = true;
    this._enrollmentService.enroll(this.userModel)
      .subscribe(
        response => console.log('Success!', response),
        error => this.errorMsg = error.statusText
      )
  }
  
}

